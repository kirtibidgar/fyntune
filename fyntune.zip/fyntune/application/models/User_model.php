<?php 

class User_model extends CI_Model {

    function isvalidate($username,$password){

        $data=$this->db->where(['username'=>$username,'password' =>$password])
                        ->get('user');
                    if($data->num_rows()){
                        return $data->row();
                    }else{
                        return false;
                    }
                        
    }

function registration($posts_data){
return $this->db->insert('user',$posts_data);                 
}


function insert_score($data){
    return $this->db->insert('user_score',$data);                 
}


function user_score_details(){
    $user_id=$this->session->userdata('userdetail')->id;
    $data=$this->db->join('user_score','user_score.user_id=user.id')
                    ->where('user_id',$user_id)
                   ->get('user');

        return $data->result();

                    
}

function num_rows(){

    $data=$this->db->get('user');              
                 return $data->num_rows();
    }
}
?>
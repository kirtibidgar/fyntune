<?php 

class Admin_model extends CI_Model {


        function isvalidate($username,$password){

            $data=$this->db->where(['username'=>$username,'password' =>$password])
                            ->get('admin');
                        if($data->num_rows()){
                            return $data->row();
                        }else{
                            return false;
                        }
                            
        }


        function num_rows(){
            $session_id=$this->session->userdata('admindetail')->id;
            $data=$this->db->where('id',$session_id)
                        ->get('user');              
                        return $data->num_rows();
            }



 function user_list(){

            $this->db->select("user.* ");
            $this->db->from('user');
            $query = $this->db->get();
            return $result = $query->result();                 
}


        function userdetails($id){
            $data=$this->db->join('user_score','user_score.user_id=user.id')
                            ->where('user_id',$id)
                        ->get('user');
                return $data->result();                    
        }


        function getSearch($search) 
        {    
                $query = "select id, name from user where name like '".$search."%'  ";
                $query = $this->db->query($query);
                return $query->result();		
        }


}
?>
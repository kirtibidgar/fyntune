<?php include('header.php');?>
<?php
$userdetails=$this->session->userdata('userdetail');
// echo $userdetails->name;

?>

<h1  style="text-align:center;margin-top:5px;"> Welcome  <?= ucwords($userdetails->name) ?> </h1>



<div class="container" style="margin-top:50px;">


<?php if($error=$this->session->flashdata('msg')){
   $msg_class= $this->session->flashdata('msg_class'); ?>
<div class="row">
    <div class="col-lg-6">
         <div class="alert <?= $msg_class;?>">
             <?php echo $error ;?>
        </div>
    </div>
</div>
<?php } ?>


<form action="<?php echo base_url('user/results'); ?>" method="post">
<div class="form-group">
        <label for="exampleFormControlSelect1">Test Name</label>
        <input required class="form-control" type="text" name='test_name' >
</div>
<div class="container mt-5">
    <div class="d-flex justify-content-center row">
        <div class="col-md-10 col-lg-10">
            <div class="border">
           
                <div class="question bg-white p-3 border-bottom">
                    <div class="d-flex flex-row justify-content-between align-items-center mcq">
                        <h4>MCQ Quiz</h4><span>(10)</span>
                    </div>
                </div>
                <div class="question bg-white p-3 border-bottom">
        
                <?php $i=1; ?>
                <?php foreach ($MCQTEST as $mcq){ ?>
                    <div class="d-flex flex-row align-items-center question-title">
                        <h3 class="text-danger">Q. <?= $i ?></h3>
                        <h5 class="mt-1 ml-2"><?php echo $mcq->question; ?></h5>
                    </div>
                    <div class="ans ml-2">
                        <label class="radio"> <input type="radio" name='<?php echo "option_$i"; ?>' value="1"> <span> <?php echo $mcq->correct_answer;?></span>
                        </label>
                    </div>

                   <?php foreach($mcq->incorrect_answers as $item ){?>
                     <div class="ans ml-2">
                        <label class="radio"> <input type="radio" name='<?php echo "option_$i"; ?>' value="0"> <span> <?php echo $item;?></span>
                        </label>
                    </div>

                    <?php }   ?>

                <?php $i++; } ?>

                </div>
                <div class="d-flex flex-row justify-content-between align-items-center p-3 bg-white">
                <button class="btn btn-primary " type="submit">Submit<i class="fa fa-angle-right ml-2"></i></button>

                </form>
                <button type="button" class="btn btn-primary " onclick="goBack()">Back<i class="fa fa-angle-right ml-2"></i></button>
                </div>
           
            </div>
        </div>
    </div>
</div>              
</div>
</div>

<?php include('footer.php');?>
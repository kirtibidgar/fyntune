<?php include('header.php');?>


<div class="container" style="margin-top:20px;">
<h1>Register Form</h1>
<?php echo form_open('user/registration');?>
<div class="row">


<div class="col-lg-6">
        <div class="form-group">
            <label>Name</label>
            <?php echo form_input(['class'=>'form-control','Placeholder'=>'Enter Name','name'=>'name','value'=>set_value('name')]);?>
        </div>
    </div>
     <div class="col-lg-6" style="margin-top:35px;">
           <?php echo form_error('name');?>  
    </div>
  


    <div class="col-lg-6">
        <div class="form-group">
            <label for="exampleInputEmail1">Email</label>
            <?php echo form_input(['class'=>'form-control','Placeholder'=>'Enter Email','name'=>'email','value'=>set_value('email')]);?>
        </div>
    </div>
     <div class="col-lg-6" style="margin-top:35px;">
           <?php echo form_error('email');?>  
    </div>



    <div class="col-lg-6">
        <div class="form-group">
            <label for="exampleInputEmail1">Username</label>
            <?php echo form_input(['class'=>'form-control','Placeholder'=>'Enter Username','name'=>'username','value'=>set_value('username')]);?>
        </div>
    </div>
     <div class="col-lg-6" style="margin-top:35px;">
           <?php  echo form_error('username'); ?>  
    </div>

    

    <div class="col-lg-6">
        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <?php echo form_password(['class'=>'form-control','Placeholder'=>'Enter Password','name'=>'password','value'=>set_value('password')]);?>
        </div>
    </div>
    <div class="col-lg-6"  style="margin-top:35px;">
             <?php echo form_error('password');?>
    </div>


    <div class="col-lg-6">
        <?php echo form_submit(['class'=>'btn btn-primary','value'=>'Submit']);?>
        <?php echo form_reset(['class'=>'btn btn-secondary','value'=>'Reset','name'=>'reset']);?>     
        <a  class="btn btn-secondary" href="<?php echo base_url(); ?>">Back</a>
      
    </div>


</div>

  

</div>




<?php include('footer.php');?>

<?php include('header.php');?>
<?php
$userdetails=$this->session->userdata('userdetail');
?>

<h1  style="text-align:center;margin-top:5px;"> Welcome to <?= ucwords($userdetails->name) ?> </h1>



<div class="container" style="margin-top:50px;">

<?php if($error=$this->session->flashdata('msg')){
   $msg_class= $this->session->flashdata('msg_class'); ?>
<div class="row">
    <div class="col-lg-6">
         <div class="alert <?= $msg_class;?>">
             <?php echo $error ;?>
        </div>
    </div>
</div>
<?php } ?>

<div class="container" style="margin-top:50px;" >
<div class="row">
   <a href="<?php echo base_url('user/form'); ?>" class="btn btn-lg btn-primary" >Take Test</a>
</div>
</div>
<br>


<table  class="table table-striped">
<thead>
<tr>
<th>Sr No</th>
<th>Test Name</th>
<th>Score</th>
</tr>
</thead>
<tbody>

<?php 
if(count($userdata)):
    $i=1;
foreach($userdata as $item) : ?>
<tr>
<td><?php echo $i; ?></td>
<td><?php  echo $item->test_name; ?></td>
<td><?php  echo $item->score; ?></td>
<?php 
$i++;
endforeach;
else:
?>
<tr>
<td colspan="3"> No Data Available</td>
</tr>

<?php
endif;
 ?>
</tbody>
</table>


</div>

</div>

<?php include('footer.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
 <link href="<?php echo base_url()?>assets/css/bootstrap.min.css"  rel="stylesheet"></link> 
 <link href="<?php echo base_url()?>assets/css/custom.css"  rel="stylesheet"></link> 

    <title>User Panel</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="#">User Panel</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="col-md-10"> </div>
  <?php 
 if($this->session->userdata('userdetail')) { ?>
<button class='btn btn-danger'><a href="<?= base_url('user/logout')?>" >LOGOUT</a></button>

<?php  }  ?>
</nav>
<?php include('header.php');?>


<div class="container" style="margin-top:20px;">
<h1>User Form</h1>

<?php if($error=$this->session->flashdata('msg')):
     $msg_class= $this->session->flashdata('msg_class') ; ?>
<div class="row">
    <div class="col-lg-6">
     <div class="alert <?= $msg_class;?>">
             <?php echo $error ;?>
        </div>
    </div>
</div>

<?php endif;?>
<?php echo form_open('user/login_validation');?>
<div class="row">
    <div class="col-lg-6">
        <div class="form-group">
            <label for="exampleInputEmail1">Username</label>
            <?php echo form_input(['class'=>'form-control','Placeholder'=>'Enter Username','name'=>'username','value'=>set_value('username')]);?>
        </div>
    </div>
     <div class="col-lg-6" style="margin-top:35px;">
           <?php echo form_error('username');
           //echo form_error('username','<div class="text-danger">','</div>');?>  
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <?php echo form_password(['class'=>'form-control','Placeholder'=>'Enter Password','name'=>'password','value'=>set_value('password')]);?>
        </div>
    </div>
    <div class="col-lg-6"  style="margin-top:35px;">
             <?php echo form_error('password'); ?>
    </div>
    <div class="col-lg-6">
        <?php echo form_submit(['class'=>'btn btn-primary','value'=>'Submit','name'=>'submit']);?>
        <?php echo form_reset(['class'=>'btn btn-secondary','value'=>'Reset','name'=>'reset']);?>     
        <?php echo anchor('user/register','Sign Up','class="btn btn-secondary"');?>     
        
    </div>
</div>

  

</div>




<?php include('footer.php');?>
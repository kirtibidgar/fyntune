
<script>
function goBack() {
  window.history.back();
}
</script>
<script src="<?php echo  base_url('assets/js/jquery-3.5.1.min.js')?>"></script>  <!-- jquery file -->
<script src="<?php echo  base_url('assets/js/bootstrap.min.js')?>"></script>  <!-- javascipt file -->
</body>
</html>
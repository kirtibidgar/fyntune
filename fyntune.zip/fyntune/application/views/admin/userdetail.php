

<!--  Files Included  -->

<!-- <script src="<?php echo  base_url('assets/js/jquery-3.5.1.min.js')?>"></script>  
<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js')?>"></script> 
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery.dataTables.min.css">

<script src="<?php echo  base_url('assets/js/bootstrap.min.js')?>"></script> -->


<!--  Files Included  -->

<h2 style="text-align:center;margin-top:5px;"><?= ($userdata) ? ucwords($userdata[0]->name) : '' ?> </h2>

<table id="html5-extension"  class="table table-striped">
<thead>
<tr>
<th>Sr No</th>
<th>Test Name</th>
<th>Score</th>
</tr>
</thead>
<tbody>

<?php 
if(count($userdata)):
    $i=1;
foreach($userdata as $item) : ?>
<tr>
<td><?php echo $i; ?></td>
<td><?php  echo $item->test_name; ?></td>
<td><?php  echo $item->score; ?></td>

<?php 
$i++;
endforeach;
else:
?>
<tr>
<td colspan="3"> No Data Available</td>
</tr>

<?php
endif;
 ?>
</tbody>
</table>


<script>


$(document).ready(function () {
    // $('#html5-extension').DataTable();
$('#html5-extension').DataTable({
    'paging':false,
    'info':false
});
$('.dataTables_length').addClass('bs-select');
});

</script>


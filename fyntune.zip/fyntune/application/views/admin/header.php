<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	

<title>Admin Panel</title>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="#">Admin Panel</a>

<?php 
 if($this->session->userdata('admindetail')) { ?>


<!-- <div class="col-md-6">
                    <div class="input-group icons">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-transparent border-0 pr-2 pr-sm-3" id="basic-addon1"><i class="mdi mdi-magnify"></i></span>
                        </div>
                        <input type="search"  id="user_name" data-step="1"  class="form-control" placeholder="Search User" aria-label="Search User">
                       
                    </div>
                 
  </div> -->

<div class="col-md-9"></div>
<div class="col-md-2"><button class='btn btn-danger'><a href="<?= base_url('admin/logout')?>" >LOGOUT</a></button></div>
<?php }  ?>
</nav>



<!-- <div style="display:none;" class="user_div">   
                    
</div> -->
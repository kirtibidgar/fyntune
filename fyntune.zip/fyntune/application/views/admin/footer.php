   <!-- The Modal -->
   <div class="modal fade warning-modal" id="myModal">
      <div class="modal-dialog modal-dialog-centered modal-lg position-relative">
          
        <div class="modal-content">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
      
          <div class="modal-body px-md-5 py-5">
    <!-- Modal body start-->
                <div id="modal_data">
                
                </div>
    <!-- Modal body end  -->
           </div>
          </div>
          
        </div>
      </div>
    </div>

<script src="<?php echo  base_url('assets/js/jquery-3.5.1.min.js')?>"></script>  <!-- jquery file -->
<script src="<?php echo  base_url('assets/js/bootstrap.min.js')?>"></script>  <!-- javascipt file -->
<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js')?>"></script> 
<script>


$(document).ready(function () {
$('#user_table').DataTable({
    // 'paging':false,
    'info':false
});
$('.dataTables_length').addClass('bs-select');
});

</script>


<script>

// $("#user_name").keyup(function() {
		
// 		if($(this).val().length >= 1){				
// 					get_data();					
// 		}
// 		else {
// 			$(".user_div").hide();
// 		} 	
// });
	


// 	function get_data() {		

// 	 	$(".user_div").show();
// 		var user_name = $("#user_name").val();
// 		// console.log(user_name);
		
// 		$.get('<?php echo base_url();?>admin/search/'+user_name, function(data, status){
		
// 			$(".user_div").html(data+"<button class='btn-primary' id='cls_srch'>Close</button>");
			
// 			$("#cls_srch").click(function(){		
// 				$(".user_div").hide();				
// 			})
			
// 		$('.sclk').click(function(){			
//             $(".user_div").hide();	
//             $("#modal_data").load("<?php echo base_url();?>admin/userdetails/"+$(this).attr("id"));		    
// 		})
		
			
// 		});	   
// 	}	

</script>  
</body>
</html>
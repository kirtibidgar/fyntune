<?php include('header.php');?>

<h1  style="text-align:center;margin-top:5px;"> Welcome  admin </h1>

<div class="container" style="margin-top:50px;">
<?php if($error=$this->session->flashdata('msg')){
   $msg_class= $this->session->flashdata('msg_class'); ?>
<div class="row">
    <div class="col-lg-6">
         <div class="alert <?= $msg_class;?>">
             <?php echo $error ;?>
        </div>
    </div>
</div>
<?php } ?>

<table id="user_table" class="table table-striped">
<thead>
<tr>
<th>Sr No</th>
<th>Name</th>
<th>Email</th>
<th>Detail</th>
</tr>
</thead>
<tbody>

<?php 
if(count($UserScore)):
    $i=1;
foreach($UserScore as $item) : ?>
<tr>
<td><?php echo $i; ?></td>
<td><?php  echo $item->name; ?></td>
<td><?php  echo $item->email; ?></td>
<td><a href='#' class="view_item btn btn-primary"' id="<?php echo $item->id;?>"  data-toggle='modal' data-target='#myModal' >
  <i class="fa fa-eye" aria-hidden="true"></i></a></td>

<?php 
$i++;
endforeach;
else:
?>
<tr><td colspan="3"> No Data Available</td></tr>
<?php endif; ?>

</tbody>

</table>
</div>
<?php echo $links; ?>

<?php include('footer.php');?>
<script>

$(".view_item").click(function(){		
			 $("#modal_data").load("<?php echo base_url();?>admin/userdetails/"+$(this).attr("id"));		    
	 });


</script>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {


		public function index()
		{
		  
			if($this->session->userdata('admindetail'))	{
				redirect('admin/welcome'); 
			}else{
				$this->load->view('admin/login');  
			}     
		}

		public function login_validation()
		{
			
            $this->form_validation->set_rules("username", "Username", "required");
            $this->form_validation->set_rules("password", "Password", "required");
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
	
            if ($this->form_validation->run() != FALSE){
                    $username= $this->input->post('username');
                    $password=$this->input->post('password');
                    $login_user= $this->Admin_model->isvalidate($username, $password);
                    if(!empty($login_user))
                    {
                                $this->session->set_userdata('admindetail',$login_user);
                                redirect('admin/welcome');
                    }else{

                                $this->session->set_flashdata('msg','Invalid Usename/Password');
                                $this->session->set_flashdata('msg_class','alert-danger');
                                redirect('admin');
                    }
			}else{
				$this->load->view('admin/login');
			}
		}


		function welcome()
		{
		   if(!$this->session->userdata('admindetail'))	{
				redirect('admin'); 
			}

			$data['UserScore'] = $this->Admin_model->user_list();
			$this->load->view('admin/dashboard',$data);

		}


		function userdetails($id)
		{
			$data['userdata']=$this->Admin_model->userdetails($id);
			$this->load->view('admin/userdetail',$data);	

		}


		function search($user_name=null) {
			$result = $this->Admin_model->getSearch($user_name);
			foreach($result as $data){
				$display="<div style='background-color: white;'> <a data-toggle='modal' data-target='#myModal' class='sclk' href='#' id='$data->id'>". "$data->name"."</a></div>";
				echo $display;	
			}	
		} 


		function logout()
		{
			if(!$this->session->userdata('admindetail'))	{
				redirect('admin'); 
			}
			$this->session->unset_userdata('admindetail');
			redirect('admin'); 
		}


	
}

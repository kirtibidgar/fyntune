<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function index()
	{
		if($this->session->userdata('userdetail'))	{
			redirect('user/welcome'); 
		}else{
			$this->load->view('user/login');   
		}
	      
	}

	public function login_validation()
		{
			
            $this->form_validation->set_rules("username", "Username", "required");
            $this->form_validation->set_rules("password", "Password", "required");
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
	
            if ($this->form_validation->run() != FALSE){
                    $username= $this->input->post('username');
                    $password=$this->input->post('password');
                    $login_user= $this->User_model->isvalidate($username, $password);
                    if(!empty($login_user))
                    {
                                $this->session->set_userdata('userdetail',$login_user);
                                redirect('user/welcome');
                    }else{

                                $this->session->set_flashdata('msg','Invalid Usename/Password');
                                $this->session->set_flashdata('msg_class','alert-danger');
                                redirect('user');
                    }
			}else{
				$this->load->view('user/login');
				// redirect('user');
			}
		}




	function welcome()
	{
		
		if(!$this->session->userdata('userdetail'))	{
			redirect('user'); 
		}

		$data['userdata']=$this->User_model->user_score_details();
		$this->load->view('user/dashboard',$data);		
		
	}



	
	function form()
	{
		if(!$this->session->userdata('userdetail'))	{
			redirect('user'); 
		}

		$url = 'https://opentdb.com/api.php?amount=10';
			
			$curl = curl_init();
			
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_HEADER, false);
			
			$data = curl_exec($curl);
			
			curl_close($curl);

		
			$output=json_decode($data);
			// print_r($output);
			$result['MCQTEST']=$output->results;
		$this->load->view('user/form',$result);		
		
	}


	public function register()
	{
		$this->load->view('user/signup');		
	}

	public function registration()
		{
			$this->form_validation->set_rules("username", "Username", "required");
            $this->form_validation->set_rules("password", "Password", "required");
			$this->form_validation->set_rules("name", "Name", "required");
            $this->form_validation->set_rules("email", "Email", "required");
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
	
			$posts_data=$this->input->post();
	
			if ($this->form_validation->run() != FALSE){
				if($this->User_model->registration($posts_data))
				{
							
					$this->session->set_flashdata('msg',' User Added Successfully');
					$this->session->set_flashdata('msg_class','alert-success');
							redirect('user');
				}else{
	
							$this->session->set_flashdata('msg','User Not Added ');
							$this->session->set_flashdata('msg_class','alert-danger');
							redirect('user/register');
				}
			}else{
			
				$this->load->view('user/signup');
				

			}
		}

	function results()
	{
		if(!$this->session->userdata('userdetail'))	{
			redirect('user'); 
		}

		$option=array();
		$option['option_1']=$this->input->post('option_1');
		$option['option_2']=$this->input->post('option_2');
		$option['option_3']=$this->input->post('option_3');
		$option['option_4']=$this->input->post('option_4');
		$option['option_5']=$this->input->post('option_5');
		$option['option_6']=$this->input->post('option_6');
		$option['option_7']=$this->input->post('option_7');
		$option['option_8']=$this->input->post('option_8');
		$option['option_9']=$this->input->post('option_9');
		$option['option_10']=$this->input->post('option_10');
		
		$score=0;
		foreach($option as $res){
			$score = $score+$res;
		}

		$data['test_name']=$this->input->post('test_name');
		$data['score']=$score;
		$data['user_id']=$this->session->userdata('userdetail')->id;
		$this->User_model->insert_score($data);

		redirect('user/welcome');
	}

	function logout()
	{
		if(!$this->session->userdata('userdetail'))	{
			redirect('user'); 
		}
		 $this->session->unset_userdata('userdetail');
		 redirect('user'); 
	}

}
